# AI Alert Analysis

- Time: 2016-02-27 17:16:20+00:00
- Score: 0.0354
- Risk: LOW
- Key contributors: login_failed(+0.004), conn_suspicious(+0.000), process.command_line_entropy(+0.000), login_failed_count_1m(+0.000), login_failed_rate_1m(+0.000)

## Observations
- Host: None, User: None
- SrcIP: None, DstIP: None

## Recommended actions
- Triage related events ±5m.
- Validate user/session and process lineage.
- Contain host if malicious indicators confirmed.
