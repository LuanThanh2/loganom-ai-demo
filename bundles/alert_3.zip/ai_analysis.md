# AI Alert Analysis

- Time: 2016-02-20 17:58:40+00:00
- Score: 0.3271
- Risk: LOW
- Key contributors: login_failed(-7.665), conn_suspicious(+0.000), process.command_line_entropy(+0.000), login_failed_count_1m(+0.000), conn_suspicious_count_1m(+0.000)

## Observations
- Host: unknown, User: unknown
- SrcIP: None, DstIP: None

## Recommended actions
- Triage related events ±5m.
- Validate user/session and process lineage.
- Contain host if malicious indicators confirmed.
